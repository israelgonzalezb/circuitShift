// Updated main.js to include player controller and interaction manager
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Circuit1BioSurvival } from './circuits/Circuit1BioSurvival.js';
import { Circuit2EmotionalTerritorial } from './circuits/Circuit2EmotionalTerritorial.js';
import { PlayerController } from './components/PlayerController.js';
import { InteractionManager } from './components/InteractionManager.js';

// DOM elements
const loadingScreen = document.getElementById('loading-screen');
const progressBar = document.querySelector('.progress-bar');
const loadingMessage = document.querySelector('.loading-message');
const gameContainer = document.getElementById('game-container');
const circuitIndicator = document.getElementById('current-circuit');
const menuButton = document.getElementById('menu-button');
const menu = document.getElementById('menu');

// Game state
let currentCircuit = 1;
let isLoading = true;
let isPaused = false;
let isOrbitControlsActive = true; // For demo, toggle between orbit and player controls

// Three.js components
let scene, camera, renderer, controls;
let clock;
let player, interactionManager;

// Circuit instances
let circuits = {
    1: null,
    2: null
};

// Initialize the game
function init() {
    // Create clock
    clock = new THREE.Clock();
    
    // Create scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    
    // Create camera
    camera = new THREE.PerspectiveCamera(
        75, 
        window.innerWidth / window.innerHeight, 
        0.1, 
        1000
    );
    camera.position.set(0, 5, 20);
    
    // Create renderer
    renderer = new THREE.WebGLRenderer({ 
        antialias: true,
        alpha: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    gameContainer.appendChild(renderer.domElement);
    
    // Add orbit controls for demo
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 5;
    controls.maxDistance = 50;
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
    
    // Create player controller
    player = new PlayerController(camera, scene);
    
    // Add event listeners
    window.addEventListener('resize', onWindowResize);
    document.addEventListener('keydown', onKeyDown);
    
    // Initialize UI
    initUI();
    
    // Load circuits
    loadCircuits();
}

// Initialize UI elements
function initUI() {
    // Setup menu button
    menuButton.addEventListener('click', toggleMenu);
    
    // Setup menu options
    document.getElementById('continue-game').addEventListener('click', () => {
        menu.classList.add('hidden');
        isPaused = false;
        clock.start();
    });
    
    document.getElementById('new-game').addEventListener('click', () => {
        menu.classList.add('hidden');
        isPaused = false;
        setCircuit(1);
    });
    
    document.getElementById('settings').addEventListener('click', () => {
        console.log('Settings clicked');
    });
    
    document.getElementById('about').addEventListener('click', () => {
        console.log('About clicked');
    });
    
    // Add control mode toggle button
    const controlModeButton = document.createElement('div');
    controlModeButton.id = 'control-mode-button';
    controlModeButton.textContent = 'Toggle Controls';
    controlModeButton.style.position = 'fixed';
    controlModeButton.style.bottom = '20px';
    controlModeButton.style.right = '20px';
    controlModeButton.style.padding = '10px 15px';
    controlModeButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    controlModeButton.style.color = '#00FFFF';
    controlModeButton.style.border = '1px solid #00FFFF';
    controlModeButton.style.borderRadius = '5px';
    controlModeButton.style.cursor = 'pointer';
    controlModeButton.style.zIndex = '100';
    
    controlModeButton.addEventListener('click', toggleControlMode);
    document.body.appendChild(controlModeButton);
    
    // Add instructions
    const instructions = document.createElement('div');
    instructions.id = 'instructions';
    instructions.style.position = 'fixed';
    instructions.style.bottom = '20px';
    instructions.style.left = '20px';
    instructions.style.padding = '10px 15px';
    instructions.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    instructions.style.color = '#FFFFFF';
    instructions.style.border = '1px solid #00FFFF';
    instructions.style.borderRadius = '5px';
    instructions.style.zIndex = '100';
    instructions.style.maxWidth = '300px';
    
    instructions.innerHTML = `
        <h3 style="color: #00FFFF; margin-top: 0;">Controls:</h3>
        <p>WASD - Move</p>
        <p>Space - Jump</p>
        <p>Shift - Sprint</p>
        <p>E - Interact</p>
        <p>F - Circuit Action</p>
        <p>1-2 - Switch Circuit</p>
        <p>ESC - Menu</p>
    `;
    
    document.body.appendChild(instructions);
}

// Toggle between orbit controls and player controls
function toggleControlMode() {
    isOrbitControlsActive = !isOrbitControlsActive;
    
    if (isOrbitControlsActive) {
        // Enable orbit controls
        controls.enabled = true;
    } else {
        // Enable player controls
        controls.enabled = false;
        
        // Reset player position
        player.setPosition(new THREE.Vector3(0, 2, 0));
        player.setRotation(new THREE.Euler(0, 0, 0));
    }
}

// Toggle menu
function toggleMenu() {
    menu.classList.toggle('hidden');
    
    if (menu.classList.contains('hidden')) {
        isPaused = false;
        clock.start();
    } else {
        isPaused = true;
        clock.stop();
    }
}

// Load circuit instances
function loadCircuits() {
    // Start loading
    startLoading();
    
    // Create circuit instances
    circuits[1] = new Circuit1BioSurvival(scene, camera);
    circuits[2] = new Circuit2EmotionalTerritorial(scene, camera);
    
    // Create interaction manager
    interactionManager = new InteractionManager(player, {
        activeCircuit: circuits[currentCircuit]
    });
    
    // Initialize first circuit
    setCircuit(1);
    
    // Simulate loading progress
    simulateLoading();
}

// Set active circuit
function setCircuit(circuitNumber) {
    if (currentCircuit === circuitNumber) return;
    
    // Hide previous circuit
    if (circuits[currentCircuit]) {
        circuits[currentCircuit].group.visible = false;
    }
    
    // Set new circuit
    currentCircuit = circuitNumber;
    circuitIndicator.textContent = currentCircuit;
    
    // Initialize and show new circuit
    if (circuits[currentCircuit]) {
        if (!circuits[currentCircuit].isInitialized) {
            circuits[currentCircuit].init();
        }
        circuits[currentCircuit].group.visible = true;
        
        // Update interaction manager
        if (interactionManager) {
            interactionManager.circuitManager = {
                activeCircuit: circuits[currentCircuit]
            };
        }
    }
    
    console.log(`Switched to Circuit ${currentCircuit}`);
}

// Start loading screen
function startLoading() {
    isLoading = true;
    loadingScreen.classList.remove('hidden');
    progressBar.style.width = '0%';
    loadingMessage.textContent = 'Initializing consciousness exploration...';
}

// Simulate loading progress
function simulateLoading() {
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        progressBar.style.width = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            completeLoading();
        }
    }, 300);
}

// Complete loading
function completeLoading() {
    isLoading = false;
    
    // Delay hiding loading screen for visual effect
    setTimeout(() => {
        loadingScreen.classList.add('hidden');
        
        // Start animation loop
        animate();
    }, 1000);
}

// Animation loop
function animate() {
    if (isPaused) return;
    
    requestAnimationFrame(animate);
    
    // Get delta time
    const delta = clock.getDelta();
    
    if (isOrbitControlsActive) {
        // Update orbit controls
        controls.update();
    } else {
        // Update player controller
        player.update(delta);
        
        // Update interaction manager
        if (interactionManager) {
            interactionManager.update(delta);
        }
    }
    
    // Update active circuit
    if (circuits[currentCircuit]) {
        circuits[currentCircuit].update(delta);
    }
    
    // Render scene
    renderer.render(scene, camera);
}

// Handle window resize
function onWindowResize() {
    // Update camera
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    
    // Update renderer
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Handle key press
function onKeyDown(event) {
    switch (event.key) {
        case '1':
            setCircuit(1);
            break;
        case '2':
            setCircuit(2);
            break;
        case 'Escape':
            toggleMenu();
            break;
        case 't':
            toggleControlMode();
            break;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);
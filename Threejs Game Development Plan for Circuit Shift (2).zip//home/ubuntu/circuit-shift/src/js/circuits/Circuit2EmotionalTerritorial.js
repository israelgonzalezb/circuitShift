// Circuit 2: Emotional-Territorial - Tribal village with rival factions
import * as THREE from 'three';
import { BaseCircuit } from './BaseCircuit.js';

export class Circuit2EmotionalTerritorial extends BaseCircuit {
    constructor(scene, camera) {
        super(scene, camera);
        
        // Circuit properties
        this.name = 'Circuit 2: Emotional-Territorial';
        this.description = 'Tribal village with rival factions';
        this.circuitNumber = 2;
        
        // Circuit-specific colors
        this.primaryColor = new THREE.Color(0xFF6600); // Orange
        this.secondaryColor = new THREE.Color(0x8B4513); // Brown
        this.accentColor = new THREE.Color(0xFFFF00); // Yellow
        
        // Circuit-specific properties
        this.territorySize = 100;
        this.villageRadius = 30;
        this.factionCount = 3;
        this.structuresPerFaction = 5;
        
        // Emotional state
        this.emotionalState = {
            anger: 0.5,
            fear: 0.5,
            joy: 0.5,
            sadness: 0.5
        };
        
        // Faction territories
        this.factions = [];
        
        // Avatar aura
        this.aura = null;
    }
    
    createEnvironment() {
        console.log('Creating Emotional-Territorial environment');
        
        // Create ground
        this.createGround();
        
        // Create skybox
        this.createSkybox();
        
        // Create territories
        this.createTerritories();
    }
    
    createGround() {
        // Create ground geometry
        const geometry = new THREE.PlaneGeometry(
            this.territorySize, 
            this.territorySize, 
            32, 
            32
        );
        
        // Rotate to be horizontal
        geometry.rotateX(-Math.PI / 2);
        
        // Create material
        const material = new THREE.MeshStandardMaterial({
            color: 0xA0522D, // Sienna
            roughness: 0.8,
            metalness: 0.2
        });
        
        // Create mesh
        const ground = new THREE.Mesh(geometry, material);
        ground.receiveShadow = true;
        ground.name = 'ground';
        
        // Add to group
        this.group.add(ground);
        this.objects.push(ground);
    }
    
    createSkybox() {
        // Create skybox geometry
        const geometry = new THREE.BoxGeometry(1000, 1000, 1000);
        
        // Create skybox material
        const material = new THREE.MeshBasicMaterial({
            color: 0xFFA07A, // Light salmon
            side: THREE.BackSide
        });
        
        // Create mesh
        const skybox = new THREE.Mesh(geometry, material);
        skybox.name = 'skybox';
        
        // Add to group
        this.group.add(skybox);
    }
    
    createTerritories() {
        // Create faction territories
        const factionColors = [
            0xFF0000, // Red faction
            0x0000FF, // Blue faction
            0x00FF00  // Green faction
        ];
        
        for (let i = 0; i < this.factionCount; i++) {
            // Create faction object
            const faction = {
                id: i,
                color: new THREE.Color(factionColors[i]),
                territory: null,
                structures: [],
                npcs: [],
                influence: 0.33, // Equal influence initially
                relationship: 0 // Neutral relationship with player
            };
            
            // Create territory marker
            const angle = (i / this.factionCount) * Math.PI * 2;
            const distance = this.villageRadius;
            
            const x = Math.cos(angle) * distance;
            const z = Math.sin(angle) * distance;
            
            // Create territory geometry
            const geometry = new THREE.CircleGeometry(15, 32);
            geometry.rotateX(-Math.PI / 2);
            
            // Create material
            const material = new THREE.MeshStandardMaterial({
                color: faction.color,
                transparent: true,
                opacity: 0.3,
                roughness: 0.8,
                metalness: 0.2
            });
            
            // Create mesh
            const territory = new THREE.Mesh(geometry, material);
            territory.position.set(x, 0.1, z);
            territory.name = `territory-${i}`;
            
            // Add to group
            this.group.add(territory);
            this.objects.push(territory);
            
            // Store territory in faction
            faction.territory = territory;
            
            // Create structures for this faction
            this.createFactionStructures(faction, x, z);
            
            // Create NPCs for this faction
            this.createFactionNPCs(faction, x, z);
            
            // Add faction to list
            this.factions.push(faction);
        }
    }
    
    createFactionStructures(faction, centerX, centerZ) {
        // Create structures for this faction
        for (let i = 0; i < this.structuresPerFaction; i++) {
            // Calculate position
            const angle = (i / this.structuresPerFaction) * Math.PI * 2;
            const distance = 8 + Math.random() * 5;
            
            const x = centerX + Math.cos(angle) * distance;
            const z = centerZ + Math.sin(angle) * distance;
            
            // Create structure geometry
            let geometry;
            
            // Different structure types
            if (i === 0) {
                // Main structure (larger)
                geometry = new THREE.CylinderGeometry(3, 4, 8, 8);
            } else {
                // Regular structures
                geometry = new THREE.CylinderGeometry(1.5, 2, 4 + Math.random() * 2, 8);
            }
            
            // Create material
            const material = new THREE.MeshStandardMaterial({
                color: faction.color,
                roughness: 0.7,
                metalness: 0.3
            });
            
            // Create mesh
            const structure = new THREE.Mesh(geometry, material);
            structure.position.set(x, geometry.parameters.height / 2, z);
            structure.castShadow = true;
            structure.receiveShadow = true;
            structure.name = `structure-${faction.id}-${i}`;
            
            // Add to group
            this.group.add(structure);
            this.objects.push(structure);
            
            // Add to faction structures
            faction.structures.push(structure);
        }
    }
    
    createFactionNPCs(faction, centerX, centerZ) {
        // Create NPCs for this faction
        const npcCount = 5 + Math.floor(Math.random() * 5);
        
        for (let i = 0; i < npcCount; i++) {
            // Calculate position
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * 12;
            
            const x = centerX + Math.cos(angle) * distance;
            const z = centerZ + Math.sin(angle) * distance;
            
            // Create NPC geometry
            const geometry = new THREE.CapsuleGeometry(0.5, 1.5, 4, 8);
            
            // Create material
            const material = new THREE.MeshStandardMaterial({
                color: faction.color,
                roughness: 0.5,
                metalness: 0.5
            });
            
            // Create mesh
            const npc = new THREE.Mesh(geometry, material);
            npc.position.set(x, 1.25, z);
            npc.castShadow = true;
            npc.receiveShadow = true;
            npc.name = `npc-${faction.id}-${i}`;
            
            // Add movement data
            npc.userData.moveTarget = new THREE.Vector3(x, 1.25, z);
            npc.userData.moveSpeed = 0.5 + Math.random() * 0.5;
            npc.userData.idleTime = 0;
            npc.userData.idleTimeMax = 2 + Math.random() * 3;
            
            // Add to group
            this.group.add(npc);
            this.objects.push(npc);
            
            // Add to faction NPCs
            faction.npcs.push(npc);
        }
    }
    
    createLighting() {
        console.log('Creating Emotional-Territorial lighting');
        
        // Create directional light (sun)
        const sunLight = new THREE.DirectionalLight(0xFFCC99, 1);
        sunLight.position.set(50, 100, 50);
        sunLight.castShadow = true;
        
        // Configure shadow
        sunLight.shadow.mapSize.width = 2048;
        sunLight.shadow.mapSize.height = 2048;
        sunLight.shadow.camera.near = 0.5;
        sunLight.shadow.camera.far = 500;
        sunLight.shadow.camera.left = -100;
        sunLight.shadow.camera.right = 100;
        sunLight.shadow.camera.top = 100;
        sunLight.shadow.camera.bottom = -100;
        
        // Add to group
        this.group.add(sunLight);
        this.lights.push(sunLight);
        
        // Create ambient light
        const ambientLight = new THREE.AmbientLight(0xFFCC99, 0.5);
        this.group.add(ambientLight);
        this.lights.push(ambientLight);
        
        // Create point lights for each faction
        for (let i = 0; i < this.factionCount; i++) {
            const faction = this.factions[i];
            if (!faction || !faction.territory) continue;
            
            // Create point light
            const pointLight = new THREE.PointLight(faction.color, 1, 30);
            pointLight.position.copy(faction.territory.position);
            pointLight.position.y = 10;
            pointLight.castShadow = true;
            
            // Configure shadow
            pointLight.shadow.mapSize.width = 1024;
            pointLight.shadow.mapSize.height = 1024;
            
            // Add to group
            this.group.add(pointLight);
            this.lights.push(pointLight);
        }
    }
    
    createObjects() {
        console.log('Creating Emotional-Territorial objects');
        
        // Create central fire
        this.createCentralFire();
        
        // Create emotional aura for player
        this.createEmotionalAura();
        
        // Create boundary markers
        this.createBoundaryMarkers();
    }
    
    createCentralFire() {
        // Create fire geometry
        const geometry = new THREE.ConeGeometry(2, 4, 8);
        
        // Create material
        const material = new THREE.MeshStandardMaterial({
            color: 0xFF6600,
            emissive: 0xFF6600,
            emissiveIntensity: 0.5,
            transparent: true,
            opacity: 0.8
        });
        
        // Create mesh
        const fire = new THREE.Mesh(geometry, material);
        fire.position.set(0, 2, 0);
        fire.name = 'central-fire';
        
        // Add point light for fire
        const fireLight = new THREE.PointLight(0xFF6600, 1, 20);
        fireLight.position.set(0, 3, 0);
        fire.add(fireLight);
        
        // Add to group
        this.group.add(fire);
        this.objects.push(fire);
    }
    
    createEmotionalAura() {
        // Create aura geometry
        const geometry = new THREE.SphereGeometry(1.5, 16, 16);
        
        // Create material
        const material = new THREE.MeshStandardMaterial({
            color: this.getEmotionalColor(),
            emissive: this.getEmotionalColor(),
            emissiveIntensity: 0.5,
            transparent: true,
            opacity: 0.5
        });
        
        // Create mesh
        this.aura = new THREE.Mesh(geometry, material);
        this.aura.position.set(0, 1.5, 0);
        this.aura.name = 'emotional-aura';
        
        // Add to camera for first-person effect
        this.camera.add(this.aura);
        this.aura.position.set(0, -1, -3);
        
        this.objects.push(this.aura);
    }
    
    createBoundaryMarkers() {
        // Create boundary markers
        const markerCount = 16;
        
        for (let i = 0; i < markerCount; i++) {
            // Calculate position
            const angle = (i / markerCount) * Math.PI * 2;
            const distance = this.territorySize / 2 - 5;
            
            const x = Math.cos(angle) * distance;
            const z = Math.sin(angle) * distance;
            
            // Create marker geometry
            const geometry = new THREE.CylinderGeometry(0.5, 0.5, 5, 8);
            
            // Create material
            const material = new THREE.MeshStandardMaterial({
                color: 0xA0522D,
                roughness: 0.8,
                metalness: 0.2
            });
            
            // Create mesh
            const marker = new THREE.Mesh(geometry, material);
            marker.position.set(x, 2.5, z);
            marker.castShadow = true;
            marker.receiveShadow = true;
            marker.name = `boundary-marker-${i}`;
            
            // Add to group
            this.group.add(marker);
            this.objects.push(marker);
        }
    }
    
    createParticles() {
        console.log('Creating Emotional-Territorial particles');
        
        // Create particles for fire
        this.createFireParticles();
        
        // Create particles for emotional aura
        this.createAuraParticles();
    }
    
    createFireParticles() {
        // Create particles for central fire
        const particleCount = 200;
        
        // Create geometry
        const geometry = new THREE.BufferGeometry();
        
        // Create positions array
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const sizes = new Float32Array(particleCount);
        
        // Fill arrays
        for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            
            // Position (around central fire)
            const angle = Math.random() * Math.PI * 2;
            const radius = Math.random() * 2;
            
            positions[i3] = Math.cos(angle) * radius;
            positions[i3 + 1] = Math.random() * 6 + 2;
            positions[i3 + 2] = Math.sin(angle) * radius;
            
            // Color (fire colors)
            const colorChoice = Math.random();
            if (colorChoice < 0.3) {
                // Yellow
                colors[i3] = 1;
                colors[i3 + 1] = 1;
                colors[i3 + 2] = 0;
            } else if (colorChoice < 0.6) {
                // Orange
                colors[i3] = 1;
                colors[i3 + 1] = 0.5;
                colors[i3 + 2] = 0;
            } else {
                // Red
                colors[i3] = 1;
                colors[i3 + 1] = 0;
                colors[i3 + 2] = 0;
            }
            
            // Size
            sizes[i] = Math.random() * 0.5 + 0.1;
        }
        
        // Set attributes
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
        
        // Create material
        const material = new THREE.PointsMaterial({
            size: 0.1,
            vertexColors: true,
            transparent: true,
            opacity: 0.8
        });
        
        // Create points
        const particles = new THREE.Points(geometry, material);
        particles.position.set(0, 0, 0);
        particles.name = 'fire-particles';
        
        // Add to group
        this.group.add(particles);
        this.particles.push(particles);
    }
    
    createAuraParticles() {
        // Create particles for emotional aura
        const particleCount = 100;
        
        // Create geometry
        const geometry = new THREE.BufferGeometry();
        
        // Create positions array
        const positions = new Float32Array(particleCount * 3);
      <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>
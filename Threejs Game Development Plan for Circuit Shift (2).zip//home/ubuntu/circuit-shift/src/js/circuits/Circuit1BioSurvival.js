// Circuit 1: Bio-Survival - Primal jungle with shifting terrain
import * as THREE from 'three';
import { BaseCircuit } from './BaseCircuit.js';

export class Circuit1BioSurvival extends BaseCircuit {
    constructor(scene, camera) {
        super(scene, camera);
        
        // Circuit properties
        this.name = 'Circuit 1: Bio-Survival';
        this.description = 'Primal jungle with shifting terrain';
        this.circuitNumber = 1;
        
        // Circuit-specific colors
        this.primaryColor = new THREE.Color(0x00AA00); // Earthy green
        this.secondaryColor = new THREE.Color(0x8B4513); // Brown
        this.accentColor = new THREE.Color(0xFFFF00); // Yellow
        
        // Circuit-specific properties
        this.terrainSize = 100;
        this.terrainSegments = 128;
        this.terrainHeight = 10;
        this.treeDensity = 0.01;
        this.hazardCount = 5;
        
        // Breathing mechanic
        this.breathingPhase = 0;
        this.breathingTarget = 0;
        this.breathingAligned = false;
        this.breathingPulse = null;
    }
    
    createEnvironment() {
        console.log('Creating Bio-Survival environment');
        
        // Create terrain
        this.createTerrain();
        
        // Create skybox
        this.createSkybox();
        
        // Create water
        this.createWater();
    }
    
    createTerrain() {
        // Create terrain geometry
        const geometry = new THREE.PlaneGeometry(
            this.terrainSize, 
            this.terrainSize, 
            this.terrainSegments, 
            this.terrainSegments
        );
        
        // Rotate to be horizontal
        geometry.rotateX(-Math.PI / 2);
        
        // Apply height map
        const vertices = geometry.attributes.position.array;
        for (let i = 0; i < vertices.length; i += 3) {
            // Skip x and z coordinates
            const y = i + 1;
            
            // Generate height using simplex noise (simulated here)
            const x = vertices[i];
            const z = vertices[i + 2];
            
            // Simple height calculation for prototype
            vertices[y] = Math.sin(x * 0.1) * Math.cos(z * 0.1) * this.terrainHeight;
        }
        
        // Update geometry
        geometry.computeVertexNormals();
        
        // Create material
        const material = new THREE.MeshStandardMaterial({
            color: this.secondaryColor,
            roughness: 0.8,
            metalness: 0.2,
            wireframe: false
        });
        
        // Create mesh
        const terrain = new THREE.Mesh(geometry, material);
        terrain.receiveShadow = true;
        terrain.name = 'terrain';
        
        // Add to group
        this.group.add(terrain);
        this.objects.push(terrain);
        
        // Add trees and vegetation
        this.addVegetation();
        
        // Add hazards
        this.addHazards();
    }
    
    addVegetation() {
        // Create tree instances
        const treeCount = Math.floor(this.terrainSize * this.terrainSize * this.treeDensity);
        
        // Create tree geometry (simplified for prototype)
        const trunkGeometry = new THREE.CylinderGeometry(0.2, 0.4, 4, 8);
        const leavesGeometry = new THREE.ConeGeometry(2, 4, 8);
        
        // Position leaves on top of trunk
        leavesGeometry.translate(0, 4, 0);
        
        // Create materials
        const trunkMaterial = new THREE.MeshStandardMaterial({
            color: this.secondaryColor,
            roughness: 0.9,
            metalness: 0.1
        });
        
        const leavesMaterial = new THREE.MeshStandardMaterial({
            color: this.primaryColor,
            roughness: 0.8,
            metalness: 0.2
        });
        
        // Create tree group
        const treeGroup = new THREE.Group();
        treeGroup.name = 'vegetation';
        
        // Create trunk and leaves
        const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
        trunk.castShadow = true;
        trunk.receiveShadow = true;
        
        const leaves = new THREE.Mesh(leavesGeometry, leavesMaterial);
        leaves.castShadow = true;
        leaves.receiveShadow = true;
        
        // Add to tree group
        treeGroup.add(trunk);
        treeGroup.add(leaves);
        
        // Create instanced mesh for trees
        const treeMatrix = new THREE.Matrix4();
        const treeInstancedMesh = new THREE.InstancedMesh(
            treeGroup.children[0].geometry,
            treeGroup.children[0].material,
            treeCount
        );
        
        const leavesInstancedMesh = new THREE.InstancedMesh(
            treeGroup.children[1].geometry,
            treeGroup.children[1].material,
            treeCount
        );
        
        // Position trees randomly
        for (let i = 0; i < treeCount; i++) {
            const x = (Math.random() - 0.5) * this.terrainSize;
            const z = (Math.random() - 0.5) * this.terrainSize;
            
            // Get height at position (simplified)
            const y = Math.sin(x * 0.1) * Math.cos(z * 0.1) * this.terrainHeight;
            
            // Create matrix for this instance
            treeMatrix.makeTranslation(x, y, z);
            
            // Add random rotation and scale
            const scale = 0.5 + Math.random() * 1.5;
            treeMatrix.scale(new THREE.Vector3(scale, scale, scale));
            
            // Set matrix for both trunk and leaves
            treeInstancedMesh.setMatrixAt(i, treeMatrix);
            leavesInstancedMesh.setMatrixAt(i, treeMatrix);
        }
        
        // Add to group
        this.group.add(treeInstancedMesh);
        this.group.add(leavesInstancedMesh);
        this.objects.push(treeInstancedMesh);
        this.objects.push(leavesInstancedMesh);
    }
    
    addHazards() {
        // Create hazards (traps, predators)
        for (let i = 0; i < this.hazardCount; i++) {
            // Create hazard geometry
            const geometry = new THREE.SphereGeometry(1, 16, 16);
            
            // Create material
            const material = new THREE.MeshStandardMaterial({
                color: 0xFF0000,
                emissive: 0xFF0000,
                emissiveIntensity: 0.5,
                roughness: 0.3,
                metalness: 0.7
            });
            
            // Create mesh
            const hazard = new THREE.Mesh(geometry, material);
            
            // Position randomly
            const x = (Math.random() - 0.5) * this.terrainSize * 0.8;
            const z = (Math.random() - 0.5) * this.terrainSize * 0.8;
            
            // Get height at position (simplified)
            const y = Math.sin(x * 0.1) * Math.cos(z * 0.1) * this.terrainHeight + 2;
            
            hazard.position.set(x, y, z);
            hazard.name = `hazard-${i}`;
            
            // Add to group
            this.group.add(hazard);
            this.objects.push(hazard);
        }
    }
    
    createSkybox() {
        // Create skybox geometry
        const geometry = new THREE.BoxGeometry(1000, 1000, 1000);
        
        // Create skybox material
        const material = new THREE.MeshBasicMaterial({
            color: 0x88CCFF,
            side: THREE.BackSide
        });
        
        // Create mesh
        const skybox = new THREE.Mesh(geometry, material);
        skybox.name = 'skybox';
        
        // Add to group
        this.group.add(skybox);
    }
    
    createWater() {
        // Create water geometry
        const geometry = new THREE.PlaneGeometry(
            this.terrainSize * 1.5, 
            this.terrainSize * 1.5, 
            32, 
            32
        );
        
        // Rotate to be horizontal
        geometry.rotateX(-Math.PI / 2);
        
        // Create material
        const material = new THREE.MeshStandardMaterial({
            color: 0x0077FF,
            transparent: true,
            opacity: 0.7,
            roughness: 0.1,
            metalness: 0.8
        });
        
        // Create mesh
        const water = new THREE.Mesh(geometry, material);
        water.position.y = -5;
        water.name = 'water';
        
        // Add to group
        this.group.add(water);
        this.objects.push(water);
    }
    
    createLighting() {
        console.log('Creating Bio-Survival lighting');
        
        // Create directional light (sun)
        const sunLight = new THREE.DirectionalLight(0xFFFFAA, 1);
        sunLight.position.set(50, 100, 50);
        sunLight.castShadow = true;
        
        // Configure shadow
        sunLight.shadow.mapSize.width = 2048;
        sunLight.shadow.mapSize.height = 2048;
        sunLight.shadow.camera.near = 0.5;
        sunLight.shadow.camera.far = 500;
        sunLight.shadow.camera.left = -100;
        sunLight.shadow.camera.right = 100;
        sunLight.shadow.camera.top = 100;
        sunLight.shadow.camera.bottom = -100;
        
        // Add to group
        this.group.add(sunLight);
        this.lights.push(sunLight);
        
        // Create ambient light
        const ambientLight = new THREE.AmbientLight(0x88AAFF, 0.5);
        this.group.add(ambientLight);
        this.lights.push(ambientLight);
        
        // Create breathing pulse light
        this.createBreathingPulse();
    }
    
    createBreathingPulse() {
        // Create point light for breathing visualization
        const breathLight = new THREE.PointLight(0xFFFF00, 0, 20);
        breathLight.position.set(0, 2, 0);
        
        // Create sphere to visualize the light
        const geometry = new THREE.SphereGeometry(0.5, 16, 16);
        const material = new THREE.MeshBasicMaterial({
            color: 0xFFFF00,
            transparent: true,
            opacity: 0.7
        });
        
        const breathSphere = new THREE.Mesh(geometry, material);
        breathLight.add(breathSphere);
        
        // Add to group
        this.group.add(breathLight);
        this.lights.push(breathLight);
        
        // Store reference
        this.breathingPulse = breathLight;
    }
    
    createParticles() {
        console.log('Creating Bio-Survival particles');
        
        // Create particles for atmosphere (mist, insects, etc.)
        const particleCount = 1000;
        
        // Create geometry
        const geometry = new THREE.BufferGeometry();
        
        // Create positions array
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const sizes = new Float32Array(particleCount);
        
        // Fill arrays
        for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            
            // Position
            positions[i3] = (Math.random() - 0.5) * this.terrainSize;
            positions[i3 + 1] = Math.random() * 20;
            positions[i3 + 2] = (Math.random() - 0.5) * this.terrainSize;
            
            // Color
            colors[i3] = 0.5 + Math.random() * 0.5; // R
            colors[i3 + 1] = 0.5 + Math.random() * 0.5; // G
            colors[i3 + 2] = 0; // B
            
            // Size
            sizes[i] = Math.random() * 0.5;
        }
        
        // Set attributes
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
        
        // Create material
        const material = new THREE.PointsMaterial({
            size: 0.1,
            vertexColors: true,
            transparent: true,
            opacity: 0.6
        });
        
        // Create points
        const particles = new THREE.Points(geometry, material);
        particles.name = 'particles';
        
        // Add to group
        this.group.add(particles);
        this.particles.push(particles);
    }
    
    updateObjects(delta) {
        // Update terrain (subtle movement)
        const terrain = this.objects.find(obj => obj.name === 'terrain');
        if (terrain) {
            // Subtle terrain movement
            const vertices = terrain.geometry.attributes.position.array;
            const time = Date.now() * 0.0002;
            
            for (let i = 0; i < vertices.length; i += 3) {
                // Skip x and z coordinates
                const y = i + 1;
                
                // Get original x and z
                const x = vertices[i];
                const z = vertices[i + 2];
                
                // Apply subtle wave motion
                vertices[y] = Math.sin(x * 0.1 + time) * Math.cos(z * 0.1 + time) * this.terrainHeight;
            }
            
            terrain.geometry.attributes.position.needsUpdate = true;
            terrain.geometry.computeVertexNormals();
        }
        
        // Update hazards (pulsating)
        for (let i = 0; i < this.hazardCount; i++) {
            const hazard = this.objects.find(obj => obj.name === `hazard-${i}`);
            if (hazard) {
                // Pulsate size
                const scale = 1 + Math.sin(Date.now() * 0.002 + i) * 0.2;
                hazard.scale.set(scale, scale, scale);
                
                // Move slightly
                hazard.position.y += Math.sin(Date.now() * 0.001 + i) * 0.01;
            }
        }
        
        // Update water
        const water = this.objects.find(obj => obj.name === 'water');
        if (water) {
            // Subtle wave effect
            water.position.y = -5 + Math.sin(Date.now() * 0.0005) * 0.5;
        }
    }
    
    updateParticles(delta) {
        // Update particles
        if (this.particles.length > 0) {
            const particles = this.particles[0];
            
            // Move particles
            const positions = particles.geometry.attributes.position.array;
            const time = Date.now() * 0.001;
            
            for (let i = 0; i < positions.length; i += 3) {
                // Move in sine wave pattern
                positions[i] += Math.sin(time + i) * 0.01;
                positions[i + 1] += Math.cos(time + i) * 0.005;
                positions[i + 2] += Math.sin(time * 0.5 + i) * 0.01;
                
                // Wrap around if out of bounds
                if (positions[i] > this.terrainSize / 2) positions[i] = -this.terrainSize / 2;
                if (positions[i] < -this.terrainSize / 2) positions[i] = this.terrainSize / 2;
                if (positions[i + 1] > 20) positions[i + 1] = 0;
                if (positions[i + 1] < 0) positions[i + 1] = 20;
                if (positions[i + 2] > this.terrainSize / 2) positions[i + 2] = -this.terrainSize / 2;
                if (positions[i + 2] < -this.terrainSize / 2) positions[i + 2] = this.terrainSize / 2;
            }
            
            particles.geometry.attributes.position.needsUpdate = true;
        }
    }
    
    updateLighting(delta) {
        // Update sun position
        const sunLight = this.lights[0];
        if (sunLight) {
            // Slowly move sun
            const time = Date.now() * 0.0001;
            sunLight.position.x = Math.sin(time) * 100;
            sunLight.position.z = Math.cos(time) * 100;
        }
        
        // Update breathing pulse
        if (this.breathingPulse) {
            // Calculate breathing phase
            this.breathingPhase += delta * 0.5;
            if (this.breathingPhase > Math.PI * 2) {
                this.breathingPhase -= Math.PI * 2;
            }
            
            // Calculate breathing value (0-1)
            const breathValue = (Math.sin(this.breathingPhase) + 1) * 0.5;
            
            // Update light intensity
            this.breathingPulse.intensity = breathValue * 2;
            
<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>
// Visual Effects Manager - Handles post-processing effects for the game
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { GlitchPass } from 'three/examples/jsm/postprocessing/GlitchPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { RGBShiftShader } from 'three/examples/jsm/shaders/RGBShiftShader.js';

export class VisualEffectsManager {
    constructor(renderer, scene, camera) {
        this.renderer = renderer;
        this.scene = scene;
        this.camera = camera;
        
        // Effect composer
        this.composer = null;
        
        // Effect passes
        this.renderPass = null;
        this.bloomPass = null;
        this.glitchPass = null;
        this.rgbShiftPass = null;
        
        // Effect settings
        this.bloomStrength = 1.5;
        this.bloomRadius = 0.4;
        this.bloomThreshold = 0.85;
        this.glitchEnabled = false;
        this.rgbShiftAmount = 0.0015;
        
        // Initialize effects
        this.init();
    }
    
    init() {
        // Create composer
        this.composer = new EffectComposer(this.renderer);
        
        // Create render pass
        this.renderPass = new RenderPass(this.scene, this.camera);
        this.composer.addPass(this.renderPass);
        
        // Create bloom pass
        this.bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            this.bloomStrength,
            this.bloomRadius,
            this.bloomThreshold
        );
        this.composer.addPass(this.bloomPass);
        
        // Create RGB shift pass
        this.rgbShiftPass = new ShaderPass(RGBShiftShader);
        this.rgbShiftPass.uniforms['amount'].value = this.rgbShiftAmount;
        this.rgbShiftPass.uniforms['angle'].value = 0;
        this.composer.addPass(this.rgbShiftPass);
        
        // Create glitch pass
        this.glitchPass = new GlitchPass();
        this.glitchPass.goWild = false;
        this.glitchPass.enabled = this.glitchEnabled;
        this.composer.addPass(this.glitchPass);
        
        console.log('Visual effects initialized');
    }
    
    update(delta) {
        // Animate RGB shift angle
        this.rgbShiftPass.uniforms['angle'].value += delta * 0.5;
        
        // Occasionally trigger glitch effect
        if (Math.random() < 0.01) {
            this.triggerGlitch();
        }
    }
    
    resize(width, height) {
        // Update composer size
        this.composer.setSize(width, height);
    }
    
    setBloomStrength(strength) {
        this.bloomStrength = strength;
        if (this.bloomPass) {
            this.bloomPass.strength = strength;
        }
    }
    
    setBloomRadius(radius) {
        this.bloomRadius = radius;
        if (this.bloomPass) {
            this.bloomPass.radius = radius;
        }
    }
    
    setBloomThreshold(threshold) {
        this.bloomThreshold = threshold;
        if (this.bloomPass) {
            this.bloomPass.threshold = threshold;
        }
    }
    
    setRGBShiftAmount(amount) {
        this.rgbShiftAmount = amount;
        if (this.rgbShiftPass) {
            this.rgbShiftPass.uniforms['amount'].value = amount;
        }
    }
    
    enableGlitch(enable) {
        this.glitchEnabled = enable;
        if (this.glitchPass) {
            this.glitchPass.enabled = enable;
        }
    }
    
    triggerGlitch() {
        // Temporarily enable glitch effect
        if (this.glitchPass) {
            const wasEnabled = this.glitchPass.enabled;
            
            // Enable glitch
            this.glitchPass.enabled = true;
            this.glitchPass.goWild = true;
            
            // Disable after a short time
            setTimeout(() => {
                this.glitchPass.goWild = false;
                this.glitchPass.enabled = wasEnabled;
            }, 200);
        }
    }
    
    setCircuitEffects(circuitNumber) {
        // Set effects based on circuit
        switch (circuitNumber) {
            case 1: // Bio-Survival
                this.setBloomStrength(1.0);
                this.setBloomRadius(0.3);
                this.setBloomThreshold(0.85);
                this.setRGBShiftAmount(0.001);
                this.enableGlitch(false);
                break;
            case 2: // Emotional-Territorial
                this.setBloomStrength(1.2);
                this.setBloomRadius(0.4);
                this.setBloomThreshold(0.8);
                this.setRGBShiftAmount(0.002);
                this.enableGlitch(false);
                break;
            case 3: // Semantic-Time Binding
                this.setBloomStrength(1.5);
                this.setBloomRadius(0.5);
                this.setBloomThreshold(0.75);
                this.setRGBShiftAmount(0.003);
                this.enableGlitch(false);
                break;
            case 4: // Social-Sexual
                this.setBloomStrength(1.8);
                this.setBloomRadius(0.6);
                this.setBloomThreshold(0.7);
                this.setRGBShiftAmount(0.004);
                this.enableGlitch(false);
                break;
            case 5: // Somatic-Neurosomatic
                this.setBloomStrength(2.0);
                this.setBloomRadius(0.7);
                this.setBloomThreshold(0.65);
                this.setRGBShiftAmount(0.005);
                this.enableGlitch(false);
                break;
            case 6: // Neuroelectric-Metaprogramming
                this.setBloomStrength(2.2);
                this.setBloomRadius(0.8);
                this.setBloomThreshold(0.6);
                this.setRGBShiftAmount(0.008);
                this.enableGlitch(true);
                break;
            case 7: // Neurogenetic
                this.setBloomStrength(2.5);
                this.setBloomRadius(0.9);
                this.setBloomThreshold(0.55);
                this.setRGBShiftAmount(0.01);
                this.enableGlitch(true);
                break;
            case 8: // Non-Local-Quantum
                this.setBloomStrength(3.0);
                this.setBloomRadius(1.0);
                this.setBloomThreshold(0.5);
                this.setRGBShiftAmount(0.015);
                this.enableGlitch(true);
                break;
            default:
                // Default effects
                this.setBloomStrength(1.5);
                this.setBloomRadius(0.4);
                this.setBloomThreshold(0.85);
                this.setRGBShiftAmount(0.0015);
                this.enableGlitch(false);
                break;
        }
    }
    
    render() {
        // Render using composer
        if (this.composer) {
            this.composer.render();
        }
    }
    
    dispose() {
        // Dispose composer and passes
        if (this.composer) {
            this.composer.dispose();
        }
    }
}

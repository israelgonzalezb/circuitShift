// Game Interaction Manager - Handles interactions between player and circuits
import * as THREE from 'three';

export class InteractionManager {
    constructor(player, circuitManager) {
        this.player = player;
        this.circuitManager = circuitManager;
        
        // Interaction state
        this.isInteracting = false;
        this.currentInteraction = null;
        this.interactionDistance = 3; // Maximum distance for interaction
        
        // Interaction targets
        this.interactableObjects = [];
        
        // Raycaster for detecting objects
        this.raycaster = new THREE.Raycaster();
        
        // Setup event listeners
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Mouse click for interaction
        document.addEventListener('click', (event) => this.onMouseClick(event));
        
        // Key press for specific interactions
        document.addEventListener('keydown', (event) => this.onKeyDown(event));
    }
    
    onMouseClick(event) {
        // Check if we're in first-person mode
        if (!this.player || !this.player.getPosition) return;
        
        // Calculate mouse position in normalized device coordinates
        const mouse = new THREE.Vector2();
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        // Update raycaster
        this.raycaster.setFromCamera(mouse, this.player.camera);
        
        // Find intersections with interactable objects
        const intersects = this.raycaster.intersectObjects(this.interactableObjects);
        
        if (intersects.length > 0) {
            // Get closest intersection
            const intersection = intersects[0];
            
            // Check if within interaction distance
            if (intersection.distance <= this.interactionDistance) {
                // Trigger interaction
                this.interact(intersection.object);
            }
        }
    }
    
    onKeyDown(event) {
        // Handle specific key interactions
        switch (event.code) {
            case 'KeyE':
                // Interact with closest object
                this.interactWithClosest();
                break;
            case 'KeyF':
                // Circuit-specific action
                this.triggerCircuitAction();
                break;
        }
    }
    
    interactWithClosest() {
        // Find closest interactable object
        if (!this.player || !this.player.getPosition) return;
        
        const playerPosition = this.player.getPosition();
        let closestObject = null;
        let closestDistance = this.interactionDistance;
        
        for (const object of this.interactableObjects) {
            const distance = playerPosition.distanceTo(object.position);
            
            if (distance < closestDistance) {
                closestDistance = distance;
                closestObject = object;
            }
        }
        
        // Interact with closest object
        if (closestObject) {
            this.interact(closestObject);
        }
    }
    
    triggerCircuitAction() {
        // Trigger circuit-specific action
        if (!this.circuitManager || !this.circuitManager.activeCircuit) return;
        
        const circuit = this.circuitManager.activeCircuit;
        
        // Different actions based on circuit
        switch (circuit.circuitNumber) {
            case 1: // Bio-Survival
                // Trigger breathing mechanic
                if (typeof circuit.alignBreath === 'function') {
                    circuit.alignBreath();
                }
                break;
            case 2: // Emotional-Territorial
                // Cycle through emotions
                if (typeof circuit.mapEmotion === 'function') {
                    const emotions = ['anger', 'fear', 'joy', 'sadness'];
                    const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
                    const randomValue = Math.random();
                    
                    circuit.mapEmotion(randomEmotion, randomValue);
                }
                break;
        }
    }
    
    interact(object) {
        // Start interaction
        this.isInteracting = true;
        this.currentInteraction = object;
        
        // Check for interaction handler
        if (object.userData && object.userData.interaction) {
            // Call interaction handler
            object.userData.interaction();
        }
        
        // Notify circuit of interaction
        if (this.circuitManager && this.circuitManager.activeCircuit) {
            this.circuitManager.activeCircuit.handleInteraction('object', {
                object: object,
                position: object.position.clone()
            });
        }
        
        // End interaction
        this.isInteracting = false;
        this.currentInteraction = null;
    }
    
    registerInteractable(object, interactionHandler) {
        // Add interaction handler
        if (!object.userData) {
            object.userData = {};
        }
        
        object.userData.interaction = interactionHandler;
        
        // Add to interactable objects
        if (!this.interactableObjects.includes(object)) {
            this.interactableObjects.push(object);
        }
    }
    
    unregisterInteractable(object) {
        // Remove from interactable objects
        const index = this.interactableObjects.indexOf(object);
        
        if (index !== -1) {
            this.interactableObjects.splice(index, 1);
        }
    }
    
    update(delta) {
        // Update interaction state
        if (this.isInteracting && this.currentInteraction) {
            // Check if still within interaction distance
            if (this.player && this.player.getPosition) {
                const playerPosition = this.player.getPosition();
                const distance = playerPosition.distanceTo(this.currentInteraction.position);
                
                if (distance > this.interactionDistance) {
                    // End interaction if too far
                    this.isInteracting = false;
                    this.currentInteraction = null;
                }
            }
        }
    }
}

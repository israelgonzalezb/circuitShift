// Create a simple player controller for the demo
import * as THREE from 'three';

export class PlayerController {
    constructor(camera, scene) {
        this.camera = camera;
        this.scene = scene;
        
        // Player state
        this.position = new THREE.Vector3(0, 2, 0);
        this.rotation = new THREE.Euler(0, 0, 0);
        this.velocity = new THREE.Vector3(0, 0, 0);
        this.moveSpeed = 5;
        this.rotationSpeed = 2;
        
        // Input state
        this.keys = {
            forward: false,
            backward: false,
            left: false,
            right: false,
            up: false,
            down: false,
            shift: false
        };
        
        // Create player mesh for third-person view
        this.createPlayerMesh();
        
        // Set up input handlers
        this.setupInputHandlers();
    }
    
    createPlayerMesh() {
        // Create player geometry
        const geometry = new THREE.CapsuleGeometry(0.5, 1, 4, 8);
        
        // Create player material
        const material = new THREE.MeshStandardMaterial({
            color: 0x00FFFF,
            emissive: 0x00FFFF,
            emissiveIntensity: 0.5,
            metalness: 0.8,
            roughness: 0.2
        });
        
        // Create player mesh
        this.mesh = new THREE.Mesh(geometry, material);
        this.mesh.position.copy(this.position);
        this.mesh.castShadow = true;
        this.mesh.receiveShadow = true;
        
        // Add to scene
        this.scene.add(this.mesh);
    }
    
    setupInputHandlers() {
        // Keyboard events
        document.addEventListener('keydown', (event) => this.onKeyDown(event));
        document.addEventListener('keyup', (event) => this.onKeyUp(event));
        
        // Mouse events for first-person camera
        document.addEventListener('mousemove', (event) => this.onMouseMove(event));
    }
    
    onKeyDown(event) {
        switch (event.code) {
            case 'KeyW':
                this.keys.forward = true;
                break;
            case 'KeyS':
                this.keys.backward = true;
                break;
            case 'KeyA':
                this.keys.left = true;
                break;
            case 'KeyD':
                this.keys.right = true;
                break;
            case 'Space':
                this.keys.up = true;
                break;
            case 'ShiftLeft':
            case 'ShiftRight':
                this.keys.shift = true;
                break;
        }
    }
    
    onKeyUp(event) {
        switch (event.code) {
            case 'KeyW':
                this.keys.forward = false;
                break;
            case 'KeyS':
                this.keys.backward = false;
                break;
            case 'KeyA':
                this.keys.left = false;
                break;
            case 'KeyD':
                this.keys.right = false;
                break;
            case 'Space':
                this.keys.up = false;
                break;
            case 'ShiftLeft':
            case 'ShiftRight':
                this.keys.shift = false;
                break;
        }
    }
    
    onMouseMove(event) {
        // Only rotate camera if right mouse button is pressed (for demo)
        if (event.buttons === 2) {
            const movementX = event.movementX || 0;
            const movementY = event.movementY || 0;
            
            this.rotation.y -= movementX * 0.002;
            this.rotation.x -= movementY * 0.002;
            
            // Clamp vertical rotation
            this.rotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, this.rotation.x));
        }
    }
    
    update(delta) {
        // Calculate movement speed
        const actualMoveSpeed = this.keys.shift ? this.moveSpeed * 2 : this.moveSpeed;
        
        // Reset velocity
        this.velocity.set(0, 0, 0);
        
        // Calculate movement direction
        if (this.keys.forward) {
            this.velocity.z -= actualMoveSpeed * delta;
        }
        if (this.keys.backward) {
            this.velocity.z += actualMoveSpeed * delta;
        }
        if (this.keys.left) {
            this.velocity.x -= actualMoveSpeed * delta;
        }
        if (this.keys.right) {
            this.velocity.x += actualMoveSpeed * delta;
        }
        if (this.keys.up) {
            this.velocity.y += actualMoveSpeed * delta;
        }
        if (this.keys.down) {
            this.velocity.y -= actualMoveSpeed * delta;
        }
        
        // Apply rotation to velocity
        const rotatedVelocity = this.velocity.clone().applyEuler(new THREE.Euler(0, this.rotation.y, 0));
        
        // Update position
        this.position.add(rotatedVelocity);
        
        // Update mesh position
        if (this.mesh) {
            this.mesh.position.copy(this.position);
            this.mesh.rotation.y = this.rotation.y;
        }
        
        // Update camera position (third-person view)
        const cameraOffset = new THREE.Vector3(0, 2, 8);
        cameraOffset.applyEuler(new THREE.Euler(0, this.rotation.y, 0));
        
        this.camera.position.copy(this.position).add(cameraOffset);
        this.camera.lookAt(this.position);
    }
    
    // Get player position
    getPosition() {
        return this.position.clone();
    }
    
    // Get player forward direction
    getForwardDirection() {
        const direction = new THREE.Vector3(0, 0, -1);
        direction.applyEuler(new THREE.Euler(0, this.rotation.y, 0));
        return direction;
    }
    
    // Set player position
    setPosition(position) {
        this.position.copy(position);
        if (this.mesh) {
            this.mesh.position.copy(position);
        }
    }
    
    // Set player rotation
    setRotation(rotation) {
        this.rotation.copy(rotation);
        if (this.mesh) {
            this.mesh.rotation.y = rotation.y;
        }
    }
}
// Game class - Main controller for the Circuit Shift game
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { CircuitManager } from './CircuitManager.js';
import { AudioManager } from '../utils/AudioManager.js';
import { PostProcessingManager } from '../utils/PostProcessingManager.js';

export class Game {
    constructor() {
        // Core Three.js components
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.clock = new THREE.Clock();
        
        // Game-specific components
        this.circuitManager = null;
        this.audioManager = null;
        this.postProcessing = null;
        
        // Game state
        this.currentCircuit = 1;
        this.isGamePaused = false;
        
        // DOM elements
        this.container = document.getElementById('game-container');
        this.circuitIndicator = document.getElementById('current-circuit');
        
        // Bind methods
        this.update = this.update.bind(this);
        this.onWindowResize = this.onWindowResize.bind(this);
    }
    
    init() {
        // Initialize Three.js scene
        this.initScene();
        
        // Initialize game components
        this.initManagers();
        
        // Add event listeners
        window.addEventListener('resize', this.onWindowResize);
        
        // Start game loop
        this.update();
        
        console.log('Circuit Shift game initialized');
    }
    
    initScene() {
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x000000);
        
        // Create camera
        this.camera = new THREE.PerspectiveCamera(
            75, 
            window.innerWidth / window.innerHeight, 
            0.1, 
            1000
        );
        this.camera.position.set(0, 2, 5);
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({ 
            antialias: true,
            alpha: true
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.container.appendChild(this.renderer.domElement);
        
        // Add orbit controls for development
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        
        // Add ambient light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);
        
        // Add directional light
        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(5, 5, 5);
        this.scene.add(directionalLight);
    }
    
    initManagers() {
        // Initialize circuit manager
        this.circuitManager = new CircuitManager(this.scene, this.camera);
        
        // Initialize audio manager
        this.audioManager = new AudioManager();
        
        // Initialize post-processing effects
        this.postProcessing = new PostProcessingManager(
            this.scene, 
            this.camera, 
            this.renderer
        );
        
        // Set initial circuit
        this.setCircuit(1);
    }
    
    setCircuit(circuitNumber) {
        if (circuitNumber < 1 || circuitNumber > 8) {
            console.error('Invalid circuit number:', circuitNumber);
            return;
        }
        
        this.currentCircuit = circuitNumber;
        this.circuitIndicator.textContent = circuitNumber;
        
        // Update circuit in managers
        this.circuitManager.setActiveCircuit(circuitNumber);
        this.audioManager.setCircuitAudio(circuitNumber);
        this.postProcessing.setCircuitEffects(circuitNumber);
        
        console.log(`Switched to Circuit ${circuitNumber}`);
    }
    
    update() {
        if (this.isGamePaused) return;
        
        const delta = this.clock.getDelta();
        
        // Update controls
        this.controls.update();
        
        // Update circuit-specific logic
        this.circuitManager.update(delta);
        
        // Update post-processing effects
        this.postProcessing.update(delta);
        
        // Render scene
        if (this.postProcessing.composer) {
            this.postProcessing.composer.render();
        } else {
            this.renderer.render(this.scene, this.camera);
        }
        
        // Continue game loop
        requestAnimationFrame(this.update);
    }
    
    onWindowResize() {
        // Update camera
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        
        // Update renderer
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        
        // Update post-processing composer
        if (this.postProcessing.composer) {
            this.postProcessing.composer.setSize(window.innerWidth, window.innerHeight);
        }
    }
    
    pause() {
        this.isGamePaused = true;
        this.audioManager.pauseAll();
    }
    
    resume() {
        this.isGamePaused = false;
        this.audioManager.resumeAll();
        this.clock.getDelta(); // Reset delta time
        this.update();
    }
    
    dispose() {
        // Remove event listeners
        window.removeEventListener('resize', this.onWindowResize);
        
        // Dispose Three.js resources
        this.scene.traverse((object) => {
            if (object.geometry) object.geometry.dispose();
            
            if (object.material) {
                if (Array.isArray(object.material)) {
                    object.material.forEach(material => material.dispose());
                } else {
                    object.material.dispose();
                }
            }
        });
        
        // Dispose renderer
        this.renderer.dispose();
        
        // Dispose managers
        this.circuitManager.dispose();
        this.audioManager.dispose();
        this.postProcessing.dispose();
        
        console.log('Game resources disposed');
    }
}

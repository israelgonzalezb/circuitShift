// CircuitManager - Manages the different circuit realms and their transitions
import * as THREE from 'three';
import { Circuit1BioSurvival } from '../circuits/Circuit1BioSurvival.js';
import { Circuit2EmotionalTerritorial } from '../circuits/Circuit2EmotionalTerritorial.js';
import { Circuit3SemanticTimeBinding } from '../circuits/Circuit3SemanticTimeBinding.js';
import { Circuit4SocialSexual } from '../circuits/Circuit4SocialSexual.js';
import { Circuit5SomaticNeurosomatic } from '../circuits/Circuit5SomaticNeurosomatic.js';
import { Circuit6NeuroelectricMetaprogramming } from '../circuits/Circuit6NeuroelectricMetaprogramming.js';
import { Circuit7Neurogenetic } from '../circuits/Circuit7Neurogenetic.js';
import { Circuit8NonLocalQuantum } from '../circuits/Circuit8NonLocalQuantum.js';

export class CircuitManager {
    constructor(scene, camera) {
        this.scene = scene;
        this.camera = camera;
        
        // Circuit instances
        this.circuits = {
            1: null, // Bio-Survival
            2: null, // Emotional-Territorial
            3: null, // Semantic-Time Binding
            4: null, // Social-Sexual
            5: null, // Somatic-Neurosomatic
            6: null, // Neuroelectric-Metaprogramming
            7: null, // Neurogenetic
            8: null  // Non-Local-Quantum
        };
        
        this.activeCircuit = null;
        this.activeCircuitNumber = 0;
        
        // Transition state
        this.isTransitioning = false;
        this.transitionProgress = 0;
        this.transitionDuration = 2.0; // seconds
        
        // Initialize placeholder for circuits
        this.initPlaceholder();
    }
    
    initPlaceholder() {
        // Create a placeholder object for when no circuit is loaded
        const geometry = new THREE.IcosahedronGeometry(1, 1);
        const material = new THREE.MeshStandardMaterial({
            color: 0x00FFFF,
            wireframe: true,
            emissive: 0x00FFFF,
            emissiveIntensity: 0.5
        });
        
        this.placeholder = new THREE.Mesh(geometry, material);
        this.scene.add(this.placeholder);
        
        // Add animation
        this.placeholder.rotation.x = Math.PI / 4;
        this.placeholder.rotation.y = Math.PI / 4;
    }
    
    setActiveCircuit(circuitNumber) {
        if (this.activeCircuitNumber === circuitNumber) return;
        
        // Start transition
        this.isTransitioning = true;
        this.transitionProgress = 0;
        
        // Lazy-load circuit if not already loaded
        if (!this.circuits[circuitNumber]) {
            this.loadCircuit(circuitNumber);
        }
        
        // Store previous circuit for transition
        const previousCircuit = this.activeCircuit;
        const previousCircuitNumber = this.activeCircuitNumber;
        
        // Set new active circuit
        this.activeCircuit = this.circuits[circuitNumber];
        this.activeCircuitNumber = circuitNumber;
        
        // Begin transition animation
        if (previousCircuit) {
            previousCircuit.prepareForTransitionOut();
        }
        
        if (this.activeCircuit) {
            this.activeCircuit.prepareForTransitionIn();
        }
        
        // Hide placeholder if we have an active circuit
        if (this.activeCircuit) {
            this.placeholder.visible = false;
        } else {
            this.placeholder.visible = true;
        }
        
        console.log(`Transitioning from Circuit ${previousCircuitNumber} to Circuit ${circuitNumber}`);
    }
    
    loadCircuit(circuitNumber) {
        // Remove placeholder if it exists
        if (this.placeholder) {
            this.placeholder.visible = false;
        }
        
        // Instantiate the appropriate circuit class
        switch (circuitNumber) {
            case 1:
                this.circuits[1] = new Circuit1BioSurvival(this.scene, this.camera);
                break;
            case 2:
                this.circuits[2] = new Circuit2EmotionalTerritorial(this.scene, this.camera);
                break;
            case 3:
                this.circuits[3] = new Circuit3SemanticTimeBinding(this.scene, this.camera);
                break;
            case 4:
                this.circuits[4] = new Circuit4SocialSexual(this.scene, this.camera);
                break;
            case 5:
                this.circuits[5] = new Circuit5SomaticNeurosomatic(this.scene, this.camera);
                break;
            case 6:
                this.circuits[6] = new Circuit6NeuroelectricMetaprogramming(this.scene, this.camera);
                break;
            case 7:
                this.circuits[7] = new Circuit7Neurogenetic(this.scene, this.camera);
                break;
            case 8:
                this.circuits[8] = new Circuit8NonLocalQuantum(this.scene, this.camera);
                break;
            default:
                console.error(`Invalid circuit number: ${circuitNumber}`);
                return;
        }
        
        // Initialize the circuit
        this.circuits[circuitNumber].init();
        
        console.log(`Loaded Circuit ${circuitNumber}`);
    }
    
    update(delta) {
        // Update placeholder rotation if visible
        if (this.placeholder && this.placeholder.visible) {
            this.placeholder.rotation.y += delta * 0.5;
            this.placeholder.rotation.x += delta * 0.2;
        }
        
        // Handle circuit transition
        if (this.isTransitioning) {
            this.transitionProgress += delta / this.transitionDuration;
            
            if (this.transitionProgress >= 1.0) {
                this.isTransitioning = false;
                this.transitionProgress = 1.0;
                
                // Finalize transition
                if (this.activeCircuit) {
                    this.activeCircuit.finalizeTransitionIn();
                }
            }
        }
        
        // Update active circuit
        if (this.activeCircuit) {
            this.activeCircuit.update(delta, this.isTransitioning ? this.transitionProgress : 1.0);
        }
    }
    
    dispose() {
        // Dispose all circuits
        for (const circuitNumber in this.circuits) {
            if (this.circuits[circuitNumber]) {
                this.circuits[circuitNumber].dispose();
            }
        }
        
        // Dispose placeholder
        if (this.placeholder) {
            this.scene.remove(this.placeholder);
            this.placeholder.geometry.dispose();
            this.placeholder.material.dispose();
        }
    }
}

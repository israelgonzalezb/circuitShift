// AudioManager - Handles all audio for the game
import { AudioListener, Audio, AudioLoader, PositionalAudio } from 'three';

export class AudioManager {
    constructor() {
        // Create audio listener
        this.listener = new AudioListener();
        
        // Audio collections
        this.backgroundTracks = {};
        this.soundEffects = {};
        
        // Current circuit audio
        this.currentCircuitTrack = null;
        this.currentCircuitNumber = 0;
        
        // Audio state
        this.isMuted = false;
        this.volume = 0.5;
        
        // Audio context
        this.context = this.listener.context;
        
        // Web Audio API nodes for effects
        this.masterGain = this.context.createGain();
        this.masterGain.gain.value = this.volume;
        this.masterGain.connect(this.context.destination);
    }
    
    init(camera) {
        // Add listener to camera
        camera.add(this.listener);
        
        // Load circuit-specific background tracks
        this.loadCircuitTracks();
        
        // Load common sound effects
        this.loadSoundEffects();
        
        console.log('Audio Manager initialized');
    }
    
    loadCircuitTracks() {
        const audioLoader = new AudioLoader();
        
        // Define circuit tracks with their characteristics
        const circuitTracks = [
            { 
                id: 1, 
                url: 'assets/audio/circuit1_biosurvival.mp3',
                description: 'Primal rhythmic beats with natural sounds'
            },
            { 
                id: 2, 
                url: 'assets/audio/circuit2_emotional.mp3',
                description: 'Emotional tribal percussion and instruments'
            },
            { 
                id: 3, 
                url: 'assets/audio/circuit3_semantic.mp3',
                description: 'Complex patterns with mathematical precision'
            },
            { 
                id: 4, 
                url: 'assets/audio/circuit4_social.mp3',
                description: 'Social interaction sounds with conversational rhythms'
            },
            { 
                id: 5, 
                url: 'assets/audio/circuit5_somatic.mp3',
                description: 'Flowing ambient soundscapes for sensory experiences'
            },
            { 
                id: 6, 
                url: 'assets/audio/circuit6_neuroelectric.mp3',
                description: 'Glitchy electronic sounds with digital artifacts'
            },
            { 
                id: 7, 
                url: 'assets/audio/circuit7_neurogenetic.mp3',
                description: 'Ancestral and archetypal sounds with organic growth'
            },
            { 
                id: 8, 
                url: 'assets/audio/circuit8_nonlocal.mp3',
                description: 'Non-local quantum soundscape with overlapping dimensions'
            }
        ];
        
        // For development, create placeholder audio tracks
        // In production, these would be replaced with actual audio files
        for (const track of circuitTracks) {
            // Create audio object
            const audio = new Audio(this.listener);
            
            // Store in collection
            this.backgroundTracks[track.id] = {
                audio: audio,
                description: track.description,
                loaded: false
            };
            
            // In a real implementation, we would load the audio file:
            // audioLoader.load(track.url, (buffer) => {
            //     audio.setBuffer(buffer);
            //     audio.setLoop(true);
            //     audio.setVolume(0.5);
            //     this.backgroundTracks[track.id].loaded = true;
            // });
            
            console.log(`Prepared audio track for Circuit ${track.id}: ${track.description}`);
        }
    }
    
    loadSoundEffects() {
        // Define common sound effects
        const soundEffects = [
            { id: 'transition', url: 'assets/audio/transition.mp3' },
            { id: 'success', url: 'assets/audio/success.mp3' },
            { id: 'failure', url: 'assets/audio/failure.mp3' },
            { id: 'menu', url: 'assets/audio/menu.mp3' },
            { id: 'click', url: 'assets/audio/click.mp3' }
        ];
        
        // For development, create placeholder sound effects
        // In production, these would be replaced with actual audio files
        for (const effect of soundEffects) {
            // Create audio object
            const audio = new Audio(this.listener);
            
            // Store in collection
            this.soundEffects[effect.id] = {
                audio: audio,
                loaded: false
            };
            
            // In a real implementation, we would load the audio file
            console.log(`Prepared sound effect: ${effect.id}`);
        }
    }
    
    setCircuitAudio(circuitNumber) {
        if (this.currentCircuitNumber === circuitNumber) return;
        
        // Stop current track if playing
        if (this.currentCircuitTrack && this.currentCircuitTrack.isPlaying) {
            this.currentCircuitTrack.stop();
        }
        
        // Set new track
        const trackData = this.backgroundTracks[circuitNumber];
        if (trackData) {
            this.currentCircuitTrack = trackData.audio;
            this.currentCircuitNumber = circuitNumber;
            
            // Play new track if loaded and not muted
            if (trackData.loaded && !this.isMuted) {
                this.currentCircuitTrack.play();
            }
            
            console.log(`Switched to Circuit ${circuitNumber} audio: ${trackData.description}`);
        } else {
            console.error(`No audio track found for Circuit ${circuitNumber}`);
        }
    }
    
    playSound(soundId) {
        const soundData = this.soundEffects[soundId];
        if (soundData && soundData.loaded && !this.isMuted) {
            // Clone the audio to allow overlapping sounds
            const sound = soundData.audio.clone();
            sound.play();
            return sound;
        }
        return null;
    }
    
    createPositionalSound(soundId, object) {
        const soundData = this.soundEffects[soundId];
        if (soundData && soundData.loaded) {
            // Create positional audio attached to the object
            const sound = new PositionalAudio(this.listener);
            sound.setBuffer(soundData.audio.buffer);
            sound.setRefDistance(20);
            object.add(sound);
            
            if (!this.isMuted) {
                sound.play();
            }
            
            return sound;
        }
        return null;
    }
    
    setMasterVolume(volume) {
        this.volume = Math.max(0, Math.min(1, volume));
        this.masterGain.gain.value = this.volume;
    }
    
    mute() {
        this.isMuted = true;
        this.masterGain.gain.value = 0;
        
        // Pause all currently playing sounds
        this.pauseAll();
    }
    
    unmute() {
        this.isMuted = false;
        this.masterGain.gain.value = this.volume;
        
        // Resume background track if we have one
        if (this.currentCircuitTrack) {
            this.currentCircuitTrack.play();
        }
    }
    
    pauseAll() {
        // Pause background track
        if (this.currentCircuitTrack && this.currentCircuitTrack.isPlaying) {
            this.currentCircuitTrack.pause();
        }
    }
    
    resumeAll() {
        // Resume background track if not muted
        if (this.currentCircuitTrack && !this.currentCircuitTrack.isPlaying && !this.isMuted) {
            this.currentCircuitTrack.play();
        }
    }
    
    dispose() {
        // Stop all sounds
        this.pauseAll();
        
        // Disconnect audio nodes
        this.masterGain.disconnect();
        
        // Clear collections
        this.backgroundTracks = {};
        this.soundEffects = {};
        
        console.log('Audio Manager disposed');
    }
}

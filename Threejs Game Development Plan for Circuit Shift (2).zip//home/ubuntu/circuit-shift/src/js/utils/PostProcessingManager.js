// PostProcessingManager - Handles visual effects for the game
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { GlitchPass } from 'three/examples/jsm/postprocessing/GlitchPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { RGBShiftShader } from 'three/examples/jsm/shaders/RGBShiftShader.js';
import { DotScreenShader } from 'three/examples/jsm/shaders/DotScreenShader.js';

export class PostProcessingManager {
    constructor(scene, camera, renderer) {
        this.scene = scene;
        this.camera = camera;
        this.renderer = renderer;
        
        // Effect composer
        this.composer = null;
        
        // Effect passes
        this.renderPass = null;
        this.bloomPass = null;
        this.rgbShiftPass = null;
        this.glitchPass = null;
        this.dotScreenPass = null;
        
        // Circuit-specific effects
        this.currentCircuitEffects = {};
        this.currentCircuitNumber = 0;
        
        // Initialize post-processing
        this.init();
    }
    
    init() {
        // Create composer
        this.composer = new EffectComposer(this.renderer);
        
        // Add render pass
        this.renderPass = new RenderPass(this.scene, this.camera);
        this.composer.addPass(this.renderPass);
        
        // Create effect passes
        this.createEffectPasses();
        
        // Set up circuit-specific effects
        this.setupCircuitEffects();
        
        console.log('Post-processing initialized');
    }
    
    createEffectPasses() {
        // Bloom pass for neon glow
        this.bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            1.5,  // strength
            0.4,  // radius
            0.85  // threshold
        );
        this.composer.addPass(this.bloomPass);
        
        // RGB shift pass for chromatic aberration
        this.rgbShiftPass = new ShaderPass(RGBShiftShader);
        this.rgbShiftPass.uniforms['amount'].value = 0.0015;
        this.rgbShiftPass.uniforms['angle'].value = 0;
        this.composer.addPass(this.rgbShiftPass);
        
        // Glitch pass for digital artifacts
        this.glitchPass = new GlitchPass();
        this.glitchPass.goWild = false;
        this.glitchPass.enabled = false;
        this.composer.addPass(this.glitchPass);
        
        // Dot screen pass for certain circuits
        this.dotScreenPass = new ShaderPass(DotScreenShader);
        this.dotScreenPass.uniforms['scale'].value = 4;
        this.dotScreenPass.enabled = false;
        this.composer.addPass(this.dotScreenPass);
    }
    
    setupCircuitEffects() {
        // Define effect configurations for each circuit
        this.circuitEffects = {
            1: { // Bio-Survival
                bloom: { strength: 0.8, radius: 0.3, threshold: 0.85 },
                rgbShift: { amount: 0.001, angle: 0 },
                glitch: { enabled: false, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            2: { // Emotional-Territorial
                bloom: { strength: 1.0, radius: 0.4, threshold: 0.8 },
                rgbShift: { amount: 0.002, angle: 0.5 },
                glitch: { enabled: false, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            3: { // Semantic-Time Binding
                bloom: { strength: 1.2, radius: 0.5, threshold: 0.75 },
                rgbShift: { amount: 0.003, angle: 1.0 },
                glitch: { enabled: false, wild: false },
                dotScreen: { enabled: true, scale: 6 }
            },
            4: { // Social-Sexual
                bloom: { strength: 1.5, radius: 0.6, threshold: 0.7 },
                rgbShift: { amount: 0.004, angle: 1.5 },
                glitch: { enabled: false, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            5: { // Somatic-Neurosomatic
                bloom: { strength: 1.8, radius: 0.7, threshold: 0.65 },
                rgbShift: { amount: 0.005, angle: 2.0 },
                glitch: { enabled: false, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            6: { // Neuroelectric-Metaprogramming
                bloom: { strength: 2.0, radius: 0.8, threshold: 0.6 },
                rgbShift: { amount: 0.008, angle: 2.5 },
                glitch: { enabled: true, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            7: { // Neurogenetic
                bloom: { strength: 2.2, radius: 0.9, threshold: 0.55 },
                rgbShift: { amount: 0.01, angle: 3.0 },
                glitch: { enabled: true, wild: false },
                dotScreen: { enabled: false, scale: 4 }
            },
            8: { // Non-Local-Quantum
                bloom: { strength: 2.5, radius: 1.0, threshold: 0.5 },
                rgbShift: { amount: 0.015, angle: 3.5 },
                glitch: { enabled: true, wild: true },
                dotScreen: { enabled: true, scale: 2 }
            }
        };
    }
    
    setCircuitEffects(circuitNumber) {
        if (this.currentCircuitNumber === circuitNumber) return;
        
        // Get effect configuration for the circuit
        const effects = this.circuitEffects[circuitNumber];
        if (!effects) {
            console.error(`No effects configuration found for Circuit ${circuitNumber}`);
            return;
        }
        
        // Store current circuit
        this.currentCircuitNumber = circuitNumber;
        this.currentCircuitEffects = effects;
        
        // Apply bloom settings
        this.bloomPass.strength = effects.bloom.strength;
        this.bloomPass.radius = effects.bloom.radius;
        this.bloomPass.threshold = effects.bloom.threshold;
        
        // Apply RGB shift settings
        this.rgbShiftPass.uniforms['amount'].value = effects.rgbShift.amount;
        this.rgbShiftPass.uniforms['angle'].value = effects.rgbShift.angle;
        
        // Apply glitch settings
        this.glitchPass.enabled = effects.glitch.enabled;
        this.glitchPass.goWild = effects.glitch.wild;
        
        // Apply dot screen settings
        this.dotScreenPass.enabled = effects.dotScreen.enabled;
        this.dotScreenPass.uniforms['scale'].value = effects.dotScreen.scale;
        
        console.log(`Applied post-processing effects for Circuit ${circuitNumber}`);
    }
    
    update(delta) {
        // Animate RGB shift angle for certain circuits
        if (this.currentCircuitNumber >= 5) {
            this.rgbShiftPass.uniforms['angle'].value += delta * 0.1;
        }
        
        // Pulse bloom strength for certain circuits
        if (this.currentCircuitNumber >= 3) {
            const baseBrightness = this.currentCircuitEffects.bloom.strength;
            const pulseFactor = Math.sin(Date.now() * 0.001) * 0.2 + 1.0;
            this.bloomPass.strength = baseBrightness * pulseFactor;
        }
        
        // Random glitch intensity for circuit 6
        if (this.currentCircuitNumber === 6 && Math.random() < 0.05) {
            this.glitchPass.goWild = true;
            setTimeout(() => {
                this.glitchPass.goWild = false;
            }, 200);
        }
    }
    
    resize(width, height) {
        // Update composer size
        this.composer.setSize(width, height);
    }
    
    dispose() {
        // Dispose composer and passes
        if (this.composer) {
            this.composer.dispose();
        }
        
        console.log('Post-processing disposed');
    }
}

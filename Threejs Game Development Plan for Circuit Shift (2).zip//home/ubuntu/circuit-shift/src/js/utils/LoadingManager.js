// LoadingManager - Handles asset loading and loading screen
export class LoadingManager {
    constructor() {
        // DOM elements
        this.loadingScreen = document.getElementById('loading-screen');
        this.progressBar = document.querySelector('.progress-bar');
        this.loadingMessage = document.querySelector('.loading-message');
        
        // Loading state
        this.totalItems = 0;
        this.loadedItems = 0;
        this.isLoading = false;
        
        // Callback for when loading is complete
        this.onComplete = null;
    }
    
    startLoading() {
        this.isLoading = true;
        this.loadingScreen.classList.remove('hidden');
        
        // Simulate loading for development
        this.simulateLoading();
        
        console.log('Loading started');
    }
    
    updateProgress(loaded, total) {
        this.loadedItems = loaded;
        this.totalItems = total;
        
        // Calculate progress percentage
        const progress = Math.min(100, Math.round((loaded / total) * 100));
        
        // Update progress bar
        this.progressBar.style.width = `${progress}%`;
        
        // Update loading message
        this.loadingMessage.textContent = `Loading assets... ${progress}%`;
        
        console.log(`Loading progress: ${progress}%`);
        
        // Check if loading is complete
        if (loaded >= total) {
            this.completeLoading();
        }
    }
    
    setLoadingMessage(message) {
        this.loadingMessage.textContent = message;
    }
    
    completeLoading() {
        this.isLoading = false;
        
        // Final loading message
        this.setLoadingMessage('Initializing consciousness exploration...');
        this.progressBar.style.width = '100%';
        
        // Delay hiding loading screen for visual effect
        setTimeout(() => {
            this.loadingScreen.classList.add('hidden');
            
            // Call onComplete callback if defined
            if (typeof this.onComplete === 'function') {
                this.onComplete();
            }
        }, 1000);
        
        console.log('Loading complete');
    }
    
    // For development, simulate loading process
    simulateLoading() {
        const totalSteps = 10;
        let currentStep = 0;
        
        const interval = setInterval(() => {
            currentStep++;
            this.updateProgress(currentStep, totalSteps);
            
            if (currentStep >= totalSteps) {
                clearInterval(interval);
            }
        }, 300);
    }
}

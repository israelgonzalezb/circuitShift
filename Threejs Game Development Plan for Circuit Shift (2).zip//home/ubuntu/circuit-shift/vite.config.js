// vite.config.js
import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    host: '0.0.0.0',
    allowedHosts: [
      '5174-ijr2mrm74in5y90ox3mep-cdcaa545.manus.computer',
      'localhost'
    ]
  }
});
